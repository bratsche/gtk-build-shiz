#include <MacHeaders.h>
#define B_ENDIAN
#ifdef __POWERPC__
#pragma longlong on
#endif
#if 1
#define MAC_OS_GUSI_SOURCE
#endif
#define MONOLITH
